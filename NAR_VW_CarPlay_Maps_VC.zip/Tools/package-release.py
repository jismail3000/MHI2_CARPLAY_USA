#!/usr/bin/env python3
"""Package the main SD release using an explicit, reviewed file list."""
from pathlib import Path
import hashlib,json,os,re,zipfile
ROOT=Path(__file__).resolve().parents[1]
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    report=json.loads((ROOT/'Source/us_map_recovery/BUILD_REPORT.json').read_text())
    common=ROOT/'Custom/carplay_maps_vc/payload/common'
    for name,info in report['outputs'].items():
        assert digest(common/name)==info['sha256'],f'Recovery binary differs from tested build: {name}'
    names=(ROOT/'Tools/release-files.txt').read_text().splitlines()
    assert len(names)==len(set(names))
    assert not any(n.startswith("Source/") for n in names), "Source belongs in the repository, not the installer ZIP"
    for name in names:
        p=Path(name)
        assert not p.is_absolute() and '..' not in p.parts,name
        assert (ROOT/p).is_file(),f'Missing release input: {name}'
    # Toolbox metadata covers only the final-script directory.
    final=ROOT/'Toolbox/final';meta=ROOT/'metainfo2.txt';data=meta.read_bytes()
    start=data.index(b'[Toolbox\\final\\Dir]');end=data.index(b'[Toolbox]',start)
    section=data[start:end]
    section=re.sub(rb'FileSize = "[0-9]+"',f'FileSize = "{sum(p.stat().st_size for p in final.rglob("*") if p.is_file())}"'.encode(),section)
    section=re.sub(rb'CheckSum = "[^"]+"',f'CheckSum = "{hashlib.sha1((final/"hashes.txt").read_bytes()).hexdigest().upper()}"'.encode(),section)
    data=data[:start]+section+data[end:]
    data=re.sub(rb'FinalScriptChecksum = "[^"]+"',f'FinalScriptChecksum = "{hashlib.sha1((final/"finalScript.sh").read_bytes()).hexdigest()}"'.encode(),data)
    if meta.read_bytes()!=data:meta.write_bytes(data)
    checks=''.join(digest(ROOT/n)+'  '+n+'\n' for n in sorted(names))
    (ROOT/'SHA256SUMS').write_text(checks)
    archive=ROOT/'NAR_VW_CarPlay_Maps_VC.zip';temporary=archive.with_suffix('.zip.tmp')
    try:
        with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for n in sorted(names+['SHA256SUMS']):
                p=ROOT/n
                info=zipfile.ZipInfo(n,(2026,11,8,0,0,0))
                info.compress_type=zipfile.ZIP_DEFLATED
                info.external_attr=(0o100000 | (p.stat().st_mode & 0o777)) << 16
                z.writestr(info,p.read_bytes())
        os.replace(temporary,archive)
    finally:
        if temporary.exists():temporary.unlink()
    archive.with_suffix('.zip.sha256').write_text(digest(archive)+'  '+archive.name+'\n')
    print(f'Packaged {len(names)+1} files: {archive.name} ({archive.stat().st_size} bytes)')
if __name__=='__main__':main()
